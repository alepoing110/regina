package com.cisco.regina.regina;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReginaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReginaApplication.class, args);
	}

}
